<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\ProjectTask */

$this->title = Yii::t('app', 'Update Project Task: {name}', [
    'name' => $model->task_id,
]);
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Project Tasks'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->task_id, 'url' => ['view', 'id' => $model->task_id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="project-task-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'project_name'=>$project_name,
        'task_category'=>$task_category,
        'task_status'=>$task_status,
    ]) ?>

</div>
