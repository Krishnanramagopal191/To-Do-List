<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\TaskStatus */

$this->title = Yii::t('app', 'Update Task Status: {name}', [
    'name' => $model->task_status_id,
]);
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Task Statuses'), 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->task_status_id, 'url' => ['view', 'id' => $model->task_status_id]];
$this->params['breadcrumbs'][] = Yii::t('app', 'Update');
?>
<div class="task-status-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
