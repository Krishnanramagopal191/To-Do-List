<?php

/* @var $this yii\web\View */

$this->title = 'To-Do List';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Welocome to To-Do List</h1>
    </div>

            </div>
        </div>

    </div>
</div>
