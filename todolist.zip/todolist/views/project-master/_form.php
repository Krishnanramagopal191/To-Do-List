<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use dosamigos\datepicker\DatePicker;
use app\models\ProjectStatus;
use app\models\ProjectCategory;
use yii\helpers\ArrayHelper;

$type_data =Yii::$app->db->createCommand("SELECT DISTINCT (project_category) as project_category from project_category where 'project_category'  IS NOT NULL and project_category !=''")->queryAll();
$type_data = ArrayHelper::map($type_data,'project_category','project_category');
$project_status_data =Yii::$app->db->createCommand("SELECT DISTINCT (project_status) as project_status from project_status where 'project_status'  IS NOT NULL and project_status !=''")->queryAll();
$project_status_data = ArrayHelper::map($project_status_data,'project_status','project_status');

/* @var $this yii\web\View */
/* @var $model app\models\ProjectMaster */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="project-master-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'project_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($project_category, 'project_category')->dropDownList(
        $type_data,
        ['prompt'=>'Select Category...']
        );
        ?>
     <?= $form->field($project_status, 'project_status')->dropDownList(
        $project_status_data,
        ['prompt'=>'Select Status...']
        );
        ?>

        <?= $form->field($model, 'deadline')->widget(
    DatePicker::className(), [
        // inline too, not bad
         'inline' => false, 
         // modify template for custom rendering
        //'template' => '<div class="well well-sm" style="background-color: #fff; width:250px">{input}</div>',
        'clientOptions' => [
            'autoclose' => true,
            'format' => 'yyyy-mm-dd'
        ]
]);?>


    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
