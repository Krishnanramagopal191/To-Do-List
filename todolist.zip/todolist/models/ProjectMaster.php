<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "project_master".
 *
 * @property int $project_id
 * @property string $project_name
 * @property int $project_category_id
 * @property string $project_category
 * @property int $project_status_id
 * @property string $project_status
 * @property string|null $deadline
 * @property string|null $created_date
 * @property string|null $updated_date
 */
class ProjectMaster extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'project_master';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['project_name',  'project_category',  'project_status'], 'required'],
            [['deadline'], 'safe'],
            [['project_name', 'project_category', 'project_status','created_by','updated_by'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'project_id' => Yii::t('app', 'Project ID'),
            'project_name' => Yii::t('app', 'Project Name'),
            'project_category_id' => Yii::t('app', 'Project Category ID'),
            'project_category' => Yii::t('app', 'Project Category'),
            'project_status_id' => Yii::t('app', 'Project Status ID'),
            'project_status' => Yii::t('app', 'Project Status'),
            'deadline' => Yii::t('app', 'Deadline'),
            'created_date' => Yii::t('app', 'Created Date'),
            'updated_date' => Yii::t('app', 'Updated Date'),
            'created_by' => Yii::t('app', 'Created By'),
            'updated_by' => Yii::t('app', 'Updated By'),
        ];
    }
    public function beforeSave($insert)
    {
       if (parent::beforeSave($insert))
       {
          if ($this->isNewRecord)
          {
            //$this->status='New';
            $this->created_date =  date('Y-m-d');
            $this->created_by = Yii::$app->user->id;
            
          }
          else
          {
            $this->updated_date =  date('Y-m-d ');
            $this->updated_by = Yii::$app->user->id;
           
          }
          return true; 
       }
       else 
       {
          return false;
       }
}
}