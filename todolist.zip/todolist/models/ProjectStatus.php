<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "project_status".
 *
 * @property int $project_status_id
 * @property string $project_status
 * @property string|null $created_date
 * @property string|null $updated_date
 */
class ProjectStatus extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'project_status';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['project_status'], 'required'],
            [['created_date', 'updated_date'], 'safe'],
            [['project_status'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'project_status_id' => Yii::t('app', 'Project Status ID'),
            'project_status' => Yii::t('app', 'Project Status'),
            'created_date' => Yii::t('app', 'Created Date'),
            'updated_date' => Yii::t('app', 'Updated Date'),
        ];
    }
}
