<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "task_category".
 *
 * @property int $task_category_id
 * @property string $task_category
 * @property string|null $created_date
 * @property string|null $updated_date
 */
class TaskCategory extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'task_category';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['task_category'], 'required'],
            [['created_date', 'updated_date'], 'safe'],
            [['task_category'], 'string', 'max' => 45],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'task_category_id' => Yii::t('app', 'Task Category ID'),
            'task_category' => Yii::t('app', 'Task Category'),
            'created_date' => Yii::t('app', 'Created Date'),
            'updated_date' => Yii::t('app', 'Updated Date'),
        ];
    }
}
